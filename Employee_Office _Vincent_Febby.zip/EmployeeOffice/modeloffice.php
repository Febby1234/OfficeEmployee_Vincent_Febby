<?php

class model_office{
    public $nama;
    public $alamat;
    public $telepon;
}
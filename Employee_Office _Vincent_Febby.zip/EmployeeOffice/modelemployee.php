<?php

class model_employee{
    public $nama;
    public $jabatan;
    public $usia;
}

?>
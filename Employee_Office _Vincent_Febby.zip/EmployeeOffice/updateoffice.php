<?php
include("controller.php");
$office = getofficebyid($_GET['id']); // gunakan huruf kecil semua
if (!$office) {
    header("Location: listoffice.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Office</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <!-- Card -->
                <div class="card shadow-lg border-0 rounded-4">
                    <div class="card-header bg-primary text-white text-center fw-bold">
                        Update Data Office
                    </div>
                    <div class="card-body p-4">

                        <form action="listoffice.php" method="post">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nama</label>
                                <input type="text" name="inputnama" class="form-control"
                                    value="<?php echo $office->nama; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Alamat</label>
                                <input type="text" name="inputalamat" class="form-control"
                                    value="<?php echo $office->alamat; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Telepon</label>
                                <input type="text" name="inputtelepon" class="form-control"
                                    value="<?php echo $office->telepon; ?>" required>
                            </div>

                            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

                            <div class="d-flex justify-content-between">
                                <a href="listoffice.php" class="btn btn-outline-secondary">Batal</a>
                                <button type="submit" name="updateoffice" class="btn btn-success px-4">
                                    Update Office
                                </button>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
</body>

</html>
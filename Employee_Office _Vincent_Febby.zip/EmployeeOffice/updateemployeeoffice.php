<?php
include("controller.php");
$id = $_GET['id'];
$employeeoffice = getemployeeofficeById($id);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employee Office</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <!-- Card -->
                <div class="card shadow-lg border-0 rounded-4">
                    <div class="card-header bg-primary text-white text-center fw-bold">
                        Update Data Employee Office
                    </div>
                    <div class="card-body p-4">

                        <form action="listemployeeoffice.php" method="post">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nama Employee</label>
                                <input type="text" name="namaemployee" class="form-control"
                                    value="<?php echo $employeeoffice->namaemployee; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nama Office</label>
                                <input type="text" name="namaoffice" class="form-control"
                                    value="<?php echo $employeeoffice->namaoffice; ?>" required>
                            </div>
                            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                            <button type="submit" name="updateemployeeoffice" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
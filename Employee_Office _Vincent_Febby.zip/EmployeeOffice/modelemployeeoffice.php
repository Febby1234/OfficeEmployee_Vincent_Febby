<?php

class model_employeeoffice{
    public $employee_id;
    public $office_id;
    public $namaemployee;
    public $namaoffice;
}
?>
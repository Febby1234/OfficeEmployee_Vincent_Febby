<?php
include("modelemployee.php");
include("modeloffice.php");
include("modelemployeeoffice.php");
session_start();

if(!isset($_SESSION['employeelist'])){
    $_SESSION ['employeelist'] = array();
}
function createemployee(){
    $employee = new model_employee();
    $employee->nama = $_POST['inputnama'];
    $employee->jabatan = $_POST['inputjabatan'];
    $employee->usia = $_POST['inputusia'];
    array_push($_SESSION['employeelist'], $employee);
}

function getemployee(){
    return $_SESSION['employeelist'];
}

if(isset($_POST['submit'])){
    createemployee();
    header("Location: listemployee.php");
}
if(isset($_GET['delete'])){
    deleteemployee($_GET['id']);
    header("Location: listemployee.php");
    exit();
}
if(isset($_POST['update'])){
    updateemployee($_POST['id']);
    header("Location: listemployee.php");
    exit();
}
function deleteemployee($id){
    unset($_SESSION['employeelist'][$id]);
}
function getemployeebyid($id){
    return $_SESSION['employeelist'][$id];
}
function updateemployee($id){
    $employee = $_SESSION['employeelist'][$id];
    $employee = getemployeebyid($id);
    $employee->nama = $_POST['inputnama'];
    $employee->jabatan = $_POST['inputjabatan'];
    $employee->usia = $_POST['inputusia'];
}

if(!isset($_SESSION['officelist'])){
    $_SESSION ['officelist'] = array();
}

function getoffice(){
    return $_SESSION['officelist'];
}

function createoffice(){
    $office = new model_office();
    $office->nama = $_POST['inputnamaoffice'];
    $office->alamat = $_POST['inputalamat'];
    $office->telepon = $_POST['inputtelepon'];
    array_push($_SESSION['officelist'], $office);
}
if(isset($_POST['submitoffice'])){
    createoffice();
    header("Location: listoffice.php");
}
if (isset($_GET['deleteoffice']) && $_GET['deleteoffice'] == 'true') {
    deleteoffice($_GET['id']);
    header("Location: listoffice.php");
    exit();
}
if(isset($_POST['updateoffice'])){
    updateoffice($_POST['id']);
    header("Location: listoffice.php");
}
function deleteoffice($id){
    unset($_SESSION['officelist'][$id]);
}
function getofficebyid($id){
    return $_SESSION['officelist'][$id];
}
function updateoffice($id){
    $office = $_SESSION['officelist'][$id];
    $office = getofficebyid($id);
    $office->nama = $_POST['inputnama'];
    $office->alamat = $_POST['inputalamat'];
    $office->telepon = $_POST['inputtelepon'];
}
function getemployeeofficebyid($id){
    return $_SESSION['employeeofficelist'][$id];
}
function getemployeeoffice(){
    return isset($_SESSION['employeeofficelist']) ? $_SESSION['employeeofficelist'] : array();
}
function deleteemployeeoffice($id){
    unset($_SESSION['employeeofficelist'][$id]);
}

if(isset($_GET['deleteemployeeoffice']) && $_GET['deleteemployeeoffice'] == 'true'){
    deleteemployeeoffice($_GET['id']);
    header("Location: listemployeeoffice.php");
    exit();
}
if(isset($_POST['updateemployeeoffice'])){
    updateemployeeoffice($_POST['id']);
    header("Location: listemployeeoffice.php");
    exit();
}
function updateemployeeoffice($id){
    $employeeoffice = $_SESSION['employeeofficelist'][$id];
    $employeeoffice->namaemployee = $_POST['namaemployee'];
    $employeeoffice->namaoffice   = $_POST['namaoffice'];
}
function createemployeeoffice(){
    $employeeoffice = new model_employeeoffice();
    $employeeoffice->employee_id = $_POST['inputemployeeid'];
    $employeeoffice->office_id = $_POST['inputofficeid'];

    $employee = $_SESSION['employeelist'][$employeeoffice->employee_id];
    $office   = $_SESSION['officelist'][$employeeoffice->office_id];

    $employeeoffice->namaemployee = $employee->nama;
    $employeeoffice->namaoffice   = $office->nama;

    $_SESSION['employeeofficelist'][] = $employeeoffice;
}
if(!isset($_SESSION['employeeofficelist'])){
    $_SESSION['employeeofficelist'] = array();
}
if(isset($_POST['add_employee_to_office'])){
    $employeeoffice = new model_employeeoffice();
    $employee_id = $_POST['employee_id'];
    $office_id = $_POST['office_id'];
    $employeeoffice->employee_id = $employee_id;
    $employeeoffice->office_id = $office_id;
    $employeeoffice->namaemployee = $_SESSION['employeelist'][$employee_id]->nama;
    $employeeoffice->namaoffice = $_SESSION['officelist'][$office_id]->nama;
    $_SESSION['employeeofficelist'][] = $employeeoffice;
    header("Location: listemployeeoffice.php");
    exit();
}

?>
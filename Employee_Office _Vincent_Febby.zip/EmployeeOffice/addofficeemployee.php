<?php

include ("controller.php");
$employeeoffices = array();
$offices = getoffice();
$employees = getemployee();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee to Office</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="listemployee.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Karyawan</a>
            <a href="listoffice.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Kantor</a>
            <a href="listemployeeoffice.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Employee Office</a>
            <a href="addofficeemployee.php" class="text-white text-lg font-semibold">Tambah Employee Office</a>
        </div>
    </nav>
    <h1 class="p-4 m-2 text-2xl font-bold text-center">Tambah Karyawan ke Kantor</h1>
    <form action="controller.php" method="post">
        <table class="table-fixed w-1/3 border border-gray-400 border-collapse mx-auto">
            <tr>
                <td class="border border-gray-400 p-2">Pilih Karyawan :</td>
                <td class="border border-gray-400 p-2">
                    <select name="employee_id" class="appearance-none border border-gray-300 rounded px-2 py-1 w-full" required>
                        <option value="" disabled selected>Pilih Karyawan</option>
                        <?php foreach ($employees as $id => $employee): ?>
                            <option value="<?php echo $id; ?>"><?php echo $employee->nama; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td class="border border-gray-400 p-2">Pilih Kantor :</td>
                <td class="border border-gray-400 p-2">
                    <select name="office_id" class="appearance-none border border-gray-300 rounded px-2 py-1 w-full" required>
                        <option value="" disabled selected>Pilih Kantor</option>
                        <?php foreach ($offices as $id => $office): ?>
                            <option value="<?php echo $id; ?>"><?php echo $office->nama; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="border border-gray-400 p-2 text-center">
                    <button type="submit" name="add_employee_to_office" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Tambah</button>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>
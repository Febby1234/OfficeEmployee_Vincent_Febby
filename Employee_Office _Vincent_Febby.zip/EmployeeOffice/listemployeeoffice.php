<?php

include ("controller.php");
$offices = getoffice();
$employees = getemployee();


?>

<!DOCTYPE html>
<html lang="en">
<title>List Employee and Office</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<header>
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="listemployee.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Karyawan</a>
            <a href="listoffice.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Kantor</a>
            <a href="listemployeeoffice.php" class="text-white text-lg font-semibold">Daftar Employee Office</a>
            <a href="addofficeemployee.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Tambah Employee Office</a>
        </div>
    </nav>
</header>

<body>
    <h1 class="p-4 m-2 text-2xl font-bold text-center">Daftar Karyawan dan Kantor</h1>
    <table class="min-w-full border border-gray-400 border-collapse mx-auto">
        <thead>
            <tr>
                <th class="border border-gray-400 p-2">Nama Karyawan</th>
                <th class="border border-gray-400 p-2">Nama Kantor</th>
                <th class="border border-gray-400 p-2">Update</th>
                <th class="border border-gray-400 p-2">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $employeeoffices = getemployeeoffice();
            if (!empty($employeeoffices)) {
                foreach ($employeeoffices as $id => $employeeoffice): ?>
                    <tr>
                        <td class="border border-gray-400 p-2"><?php echo $employeeoffice->namaemployee; ?></td>
                        <td class="border border-gray-400 p-2"><?php echo $employeeoffice->namaoffice; ?></td>
                        <td class="border border-gray-400 p-2 text-center">
                            <a href="updateemployeeoffice.php?id=<?php echo $id; ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-3 rounded">Update</a>
                        </td>
                        <td class="border border-gray-400 p-2 text-center">
                            <a href="controller.php?deleteemployeeoffice=true&id=<?php echo $id; ?>" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded">Delete</a>
                        </td>
                    </tr>
                <?php endforeach;
            } else { ?>
                <tr>
                    <td colspan="4" class="border border-gray-400 p-2 text-center">Tidak ada data employee office.</td>
                </tr>
            <?php } ?>
    </table>
</body>
</html>
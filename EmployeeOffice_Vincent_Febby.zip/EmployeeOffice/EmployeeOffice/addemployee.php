<?php include("controller.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Add Employee</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="listemployee.php" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Daftar Karyawan</a>
            <a href="addemployee.php" class="text-white text-lg font-semibold">Tambah Karyawan</a>
        </div>
    </nav>
</header>
    <h1 class="p-4 m-2 text-2xl font-bold text-center">Tambah Karyawan</h1>
<form action="listemployee.php" method="post">
    <table class="table-fixed w-1/3 border border-gray-400 border-collapse mx-auto">
        <tr>
            <td class="border border-gray-400 p-2">Nama :</td>
            <td class="border border-gray-400 p-2">
                <input
                    name="inputnama"
                    class="appearance-none border border-gray-300 rounded px-2 py-1 w-full"
                    type="text"
                    placeholder="Masukkan Nama"
                    required
                />
            </td>
        </tr>
        <tr>
            <td class="border border-gray-400 p-2">Jabatan :</td>
            <td class="border border-gray-400 p-2">
                <input
                    name="inputjabatan"
                    class="appearance-none border border-gray-300 rounded px-2 py-1 w-full"
                    type="text"
                    placeholder="Masukkan Jabatan"
                    required
                />
            </td>
        </tr>
        <tr>
            <td class="border border-gray-400 p-2">Usia :</td>
            <td class="border border-gray-400 p-2">
                <input
                    name="inputusia"
                    class="appearance-none border border-gray-300 rounded px-2 py-1 w-full"
                    type="number"
                    placeholder="Masukkan Usia"
                    required
                />
            </td>
        </tr>
        <tr>
            <td colspan="2" class="border border-gray-400 p-2 text-center">
                <button
                    type="submit"
                    name="submit"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                    Tambah Karyawan
                </button>
            </td>
        </tr>
    </table>
</form>
</body>

</html>
<?php
include("controller.php");
$employee = getemployeebyid($_GET['id']); 
if (!$employee) {
    header("Location: listemployee.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Karyawan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-6">

        <div class="card shadow-lg border-0 rounded-4">
          <div class="card-header bg-primary text-white text-center fw-bold">
            Update Data Karyawan
          </div>
          <div class="card-body p-4">
            
            <form action="listemployee.php" method="post">
              
              <div class="mb-3">
                <label class="form-label fw-semibold">Nama</label>
                <input type="text" name="inputnama" class="form-control" 
                       value="<?php echo $employee->nama; ?>" required>
              </div>

              <div class="mb-3">
                <label class="form-label fw-semibold">Jabatan</label>
                <input type="text" name="inputjabatan" class="form-control" 
                       value="<?php echo $employee->jabatan; ?>" required>
              </div>

              <div class="mb-3">
                <label class="form-label fw-semibold">Usia</label>
                <input type="number" name="inputusia" class="form-control" 
                       value="<?php echo $employee->usia; ?>" required>
              </div>

              <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

              <div class="d-flex justify-content-between">
                <a href="listemployee.php" class="btn btn-outline-secondary">Batal</a>
                <button type="submit" name="update" class="btn btn-success px-4">
                  Update Karyawan
                </button>
              </div>
            </form>

          </div>
        </div>

      </div>
    </div>
  </div>
</body>
</html>
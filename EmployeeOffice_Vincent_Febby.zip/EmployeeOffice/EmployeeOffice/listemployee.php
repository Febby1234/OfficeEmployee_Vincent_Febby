<?php
include("controller.php");
$employees = getemployee();
?>
<html>
<head>
    <title>Daftar Karyawan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<header>
    <nav class="bg-gray-800 p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="listemployee.php" class="text-white text-lg font-semibold">Daftar Karyawan</a>
            <a href="addemployee.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Tambah Karyawan</a>
        </div>
    </nav>
</header>
<body>
    <h1 class="p-4 m-2 text-2xl font-bold text-center">Daftar Karyawan</h1>
    <table class="min-w-full border border-gray-400 border-collapse mx-auto">
        <thead>
            <tr>
                <th class="border border-gray-400 p-2">Nama</th>
                <th class="border border-gray-400 p-2">Jabatan</th>
                <th class="border border-gray-400 p-2">Usia</th>
                <th class="border border-gray-400 p-2">Update</th>
                <th class="border border-gray-400 p-2">Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($employees as $id => $employee): ?>
        <tr>
            <td class="border border-gray-400 p-2"><?php echo $employee->nama; ?></td>
            <td class="border border-gray-400 p-2"><?php echo $employee->jabatan; ?></td>
            <td class="border border-gray-400 p-2"><?php echo $employee->usia; ?></td>
            <td class="border border-gray-400 p-2 text-center">
                <a href="updateemployee.php?id=<?php echo $id; ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-3 rounded">Update</a>
            </td>
            <td class="border border-gray-400 p-2 text-center">
                <a href="controller.php?delete=true&id=<?php echo $id; ?>" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
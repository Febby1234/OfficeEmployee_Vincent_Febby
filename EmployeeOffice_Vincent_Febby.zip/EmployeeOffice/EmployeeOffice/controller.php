<?php
include("modelemployee.php");
session_start();

if(!isset($_SESSION['employeelist'])){
    $_SESSION ['employeelist'] = array();
}
function createemployee(){
    $employee = new model_employee();
    $employee->nama = $_POST['inputnama'];
    $employee->jabatan = $_POST['inputjabatan'];
    $employee->usia = $_POST['inputusia'];
    array_push($_SESSION['employeelist'], $employee);
}

function getemployee(){
    return $_SESSION['employeelist'];
}

if(isset($_POST['submit'])){
    createemployee();
    header("Location: listemployee.php");
}
if(isset($_GET['delete'])){
    deleteemployee($_GET['id']);
    header("Location: listemployee.php");
}
if(isset($_POST['update'])){
    updateemployee($_POST['id']);
    header("Location: listemployee.php");
}
function deleteemployee($id){
    unset($_SESSION['employeelist'][$id]);
}
function getemployeebyid($id){
    return $_SESSION['employeelist'][$id];
}
function updateemployee($id){
    $employee = $_SESSION['employeelist'][$id];
    $employee = getemployeebyid($id);
    $employee->nama = $_POST['inputnama'];
    $employee->jabatan = $_POST['inputjabatan'];
    $employee->usia = $_POST['inputusia'];
}

?>